package com.example.guochao;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Controller
public class HomeController implements WebMvcConfigurer {
	
//17205133-郭超
      
	public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("login");
        registry.addViewController("/home").setViewName("welcome");
        registry.addViewController("/register").setViewName("register");
    }
	@GetMapping("/home")
	public String goHome(){
		return "welcome";
	}
	@PostMapping("/login")
	public String check(@Validated User user, BindingResult bindingResult, Model model) {
			if (bindingResult.hasFieldErrors()) {
				model.addAttribute(user);
				return "login";
			}else
				return "redirect:home";
		}
    @GetMapping("/")
    public String login(@ModelAttribute("user")User user, Model model){
        model.addAttribute("user",new User());
        return "login";
    }
    @GetMapping("/register")
	public String goRegister(Model model){
		model.addAttribute("user",new User());
		return "register";
	}
	@PostMapping("/register")
	public String register(@Validated User user, BindingResult bindingResult, Model model) {
			if (bindingResult.hasFieldErrors()) {
				model.addAttribute(user);
				return "register";
			}else
				return "redirect:home";
		}
}